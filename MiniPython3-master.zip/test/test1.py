# -*- coding: UTF-8 -*-
a = 2018
b = 1951
c = 21
d = 60
e = True
f = False
g = "Tsinghua"
h = "???"
print (a / c - (b / d * c + 5 * d) * (90 - d) )# 四则运算1
print (-5 + 7 * 90 / 6 / 5 * 3 + 100 * (-5) )# 四则运算2
print ((c >= d) and (a > b) or (a >= 7) and (b < 9) )# 比较运算、布尔运算
print (e and f or (a < b) )# 比较运算、布尔运算
print (1 << 2 + c >> 1 * 2 - 6 // (-3) )# 移位运算
print (9 & 8 - 6 | 7 * 2 + 9 )# 位运算
print (g + h + g[2: 6: 2] )# 字符串操作:只涉及连接、切片，不涉及字符串函数
