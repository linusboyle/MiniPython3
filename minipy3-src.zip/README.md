# MiniPy
an extremely bad-written mini python3 interpreter in C++ currently in progress

## will support:
- definition of function
- basic calculation
- program flow control
- (optional)object-oriented features
- (optional)GUI frontend,including IDE
- MORE...

## Dependencies:
- C++17 standard compatible compiler
- Qt5 (for gui)
- bison (for parser)
- gnu make and ar

## Install:
On Linux,just:
```shell
make
```
**do not attempt to run make in subdirectory**

It's not tested on Windows and Macintosh

## Doc
see more information in /doc folder with documents wrritten in Chinese
