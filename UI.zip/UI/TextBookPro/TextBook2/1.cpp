#include<iostream>

using namespace std;

int main(){


cout<<"feafa";

system("pause"); 

return 0;

}
