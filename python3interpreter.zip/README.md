# MiniPy
an extremely bad-written mini python3 interpreter in C++ currently in progress

## will support:
- definition of function
- basic calculation
- program flow control
- (optional)object-oriented features
- (optional)GUI frontend,including IDE
- MORE...
